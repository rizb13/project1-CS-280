#!/usr/bin/perl

use Getopt::Long;
my $VERBOSE;
my $ALARM = 3;
GetOptions( "verbose" => \$VERBOSE,
                "alarm=i" => \$ALARM        );


# run a system command (like runcase)
# but make sure it only runs for 1 second max -- i.e. if it hangs, kill it and fail


if( length @ARGV < 1 ) { print STDERR "ERROR: No command given to run!\n"; exit 1; }


#print STDERR "Running '$ARGV[0]'...\n" if $VERBOSE;

my $pipe;
my $pid;


$SIG{ALRM} =
  sub { print STDERR "ERROR: TIMEOUT!\n"; $g=getpgrp $pid; 
        system("kill -9 -- -$g"); exit 1; };


alarm 1;
$pid = open $pipe, "-|" // die "ERROR: CANNOT RUN COMMAND '$ARGV[0]': $! $@ $?";                                               
if($pid){} # PARENT               
elsif(defined $pid)
{
  # CHILD
  close STDIN;
  setpgrp;
  #system($ARGV[0]);
                    system(@ARGV);
  exit 0;
}                    


while(<$pipe>) { print $_; }
alarm 0; # stop alarm
$ret = close $pipe;
exit $? >> 8;
